package com.example.voting;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class Scrollbar extends AppCompatActivity {
    mydbhelper my;
    MyDatabaseHelper mydb;
    SharedPreferences sharedPreferences;
    String shared_pref_name="mypref";
    String aadharnumber="aadharnumber";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrollbar);
        sharedPreferences=getSharedPreferences(shared_pref_name,MODE_PRIVATE);
        mydb=new MyDatabaseHelper(Scrollbar.this);
        my=new mydbhelper(Scrollbar.this);
    }
    int y=0;
    public void ysrcpbutton(View view) {
        String paanum=sharedPreferences.getString(aadharnumber,null);
        mydb.updatetovoted(paanum);
        y++;
        my.upadtevote("YSRCP",y);
        Toast.makeText(this, "Voted successfully", Toast.LENGTH_SHORT).show();
        Intent intent=new Intent(Scrollbar.this,lastscreen.class);
        intent.putExtra("msg","YSRCP");
        startActivity(intent);
    }
int t=0;
    public void tdpbutton(View view) {
        String paanum=sharedPreferences.getString(aadharnumber,null);
        mydb.updatetovoted(paanum);
        t++;
        my.upadtevote("TDP",t);
        Toast.makeText(this, "Voted successfully", Toast.LENGTH_SHORT).show();
        Intent intent=new Intent(Scrollbar.this,lastscreen.class);
        intent.putExtra("msg","TDP");
        startActivity(intent);
    }
int j=0;
    public void jspbutton(View view) {
        String paanum=sharedPreferences.getString(aadharnumber,null);
        mydb.updatetovoted(paanum);
        j++;
        my.upadtevote("JSP",j);
        Toast.makeText(this, "Voted successfully", Toast.LENGTH_SHORT).show();
        Intent intent=new Intent(Scrollbar.this,lastscreen.class);
        intent.putExtra("msg","JSP");
        startActivity(intent);
    }
int i=0;
    public void incbutton(View view) {
        String paanum=sharedPreferences.getString(aadharnumber,null);
        mydb.updatetovoted(paanum);
        i++;
        my.upadtevote("INC",i);
        Toast.makeText(this, "Voted successfully", Toast.LENGTH_SHORT).show();
        Intent intent=new Intent(Scrollbar.this,lastscreen.class);
        intent.putExtra("msg","INC");
        startActivity(intent);
    }
int b=0;
    public void bjpbutton(View view) {
        String paanum=sharedPreferences.getString(aadharnumber,null);
        mydb.updatetovoted(paanum);
        b++;
        my.upadtevote("BJP",b);
        Toast.makeText(this, "Voted successfully", Toast.LENGTH_SHORT).show();
        Intent intent=new Intent(Scrollbar.this, lastscreen.class);
        intent.putExtra("msg","BJP");
        startActivity(intent);
    }
    int n=0;
    public void notabutton(View view) {
        String paanum=sharedPreferences.getString(aadharnumber,null);
        mydb.updatetovoted(paanum);
        n++;
        my.upadtevote("NOTA",n);
        Toast.makeText(this, "Voted successfully", Toast.LENGTH_SHORT).show();
        Intent intent=new Intent(Scrollbar.this,lastscreen.class);
        intent.putExtra("msg","NOTA");
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent=new Intent(Scrollbar.this,MainActivity.class);
        startActivity(intent);
    }
}