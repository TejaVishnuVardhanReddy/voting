package com.example.voting;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class mydbhelper extends SQLiteOpenHelper {
    private Context context;
    private static final String DATABASE_NAME="votes.db";
    private static  final int DATABASE_VERSION=1;
    private static final String TABLE_NAME="votes";
    private static final String COLUMN_ID="_id";
    private static final String COLUMN_PARTY_NAME="partyname";
    private static final String COLUMN_NUMOFVOTES="noofvotes";
    public mydbhelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query="CREATE TABLE "+ TABLE_NAME +" (" + COLUMN_ID +" INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_PARTY_NAME + " TEXT, " +
                COLUMN_NUMOFVOTES + " INTEGER);";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+ TABLE_NAME);
        onCreate(db);
    }
    public void adddata(){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put(COLUMN_PARTY_NAME,"NOTA");
        cv.put(COLUMN_NUMOFVOTES,0);
        long res=db.insert(TABLE_NAME,null,cv);
        if(res==-1) {
            Toast.makeText(context, "not saved", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show();
        }
        }
        public void upadtevote(String party,int i){
            String[] selectionArgs = { party };
            String selection = COLUMN_PARTY_NAME + " LIKE ?";
            SQLiteDatabase db=this.getWritableDatabase();
            ContentValues cv=new ContentValues();
            cv.put(COLUMN_NUMOFVOTES,i);
            long res=db.update(TABLE_NAME,cv,selection,selectionArgs);
        }
}
