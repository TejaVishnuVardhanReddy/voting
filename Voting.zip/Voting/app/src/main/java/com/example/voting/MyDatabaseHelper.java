package com.example.voting;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MyDatabaseHelper extends SQLiteOpenHelper {
    String aanum;
    private Context context;
    private static final String DATABASE_NAME="aadata.db";
    private static  final int DATABASE_VERSION=1;
    private static final String TABLE_NAME="aadhardata";
    private static final String COLUMN_ID="_id";
    private static final String COLUMN_aanum="aadharnum";
    private static final String COLUMN_aaname="aadharname";
    private static final String COLUMN_DOB="aadhardob";
    private static final String COLUMN_gen="aadhargen";
    private static final String COLUMN_mob="aadharmob";
    private static final String COLUMN_vstatus="votestatus";
    public MyDatabaseHelper(@Nullable Context context) {
        super(context,DATABASE_NAME, null, DATABASE_VERSION);
        this.context=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query="CREATE TABLE "+ TABLE_NAME +" (" + COLUMN_ID +" INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_aanum + " TEXT, " +
                COLUMN_aaname + " TEXT, " +
                COLUMN_DOB + " TEXT, " +
                COLUMN_gen + " TEXT, " +
                COLUMN_mob + " TEXT, " +
                COLUMN_vstatus + " INTEGER);";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+ TABLE_NAME);
        onCreate(db);
    }
    void addData(){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put(COLUMN_aanum,"654264872623");
        cv.put(COLUMN_aaname,"Sai Venkata Deepak Veluvolu");
        cv.put(COLUMN_DOB,"07/03/2003");
        cv.put(COLUMN_gen,"MALE");
        cv.put(COLUMN_mob,"7702899279");
        cv.put(COLUMN_vstatus,"YES");
        long res=db.insert(TABLE_NAME,null,cv);
        if(res==-1){
            Toast.makeText(context, "Not saved", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(context, "Saved successfully", Toast.LENGTH_SHORT).show();
        }
    }
    String readAllDAta(String aanum){
        this.aanum=aanum;
        String query="SELECT * FROM "+ TABLE_NAME +" WHERE "+ COLUMN_aanum +" = "+aanum;
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=null;
        if(db!=null){
            cursor=db.rawQuery(query,null);
        }
        cursor.moveToFirst();
        String phno=cursor.getString(5);
        cursor.close();
        return phno;
    }
    Cursor displaydata(String aanum){
        String query="SELECT * FROM "+ TABLE_NAME +" WHERE "+ COLUMN_aanum +" = "+aanum;
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=null;
        if(db!=null){
            cursor=db.rawQuery(query,null);
        }
        cursor.moveToFirst();
        return cursor;
    }
    String returnstaus(String aanum){
        String query="SELECT * FROM "+ TABLE_NAME +" WHERE "+ COLUMN_aanum +" = "+aanum;
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=null;
        if(db!=null){
            cursor=db.rawQuery(query,null);
        }
        cursor.moveToFirst();
        String vstatus=cursor.getString(6);
        cursor.close();
        return vstatus;
    }
    Cursor getallaadhars(){
        String query="SELECT * FROM "+ TABLE_NAME;
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=null;
        if(db!=null){
            cursor=db.rawQuery(query,null);
        }
        cursor.moveToFirst();
        return cursor;
    }
    void updatetono(){
        String[] selectionArgs = {"186954287788" };
        String selection = COLUMN_aanum + " LIKE ?";
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put(COLUMN_vstatus,"YES");
        long res=db.update(TABLE_NAME,cv,selection,selectionArgs);
        if(res==-1){
            Toast.makeText(context, "not voted", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(context, "voted", Toast.LENGTH_SHORT).show();
        }
    }
    void updatetovoted(String aanum){
        String[] selectionArgs = { aanum };
        String selection = COLUMN_aanum + " LIKE ?";
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put(COLUMN_vstatus,"YES");
        long res=db.update(TABLE_NAME,cv,selection,selectionArgs);
    }
}
