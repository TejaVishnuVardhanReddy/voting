package com.example.voting;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    mydbhelper my;
    ProgressBar pb;
    SharedPreferences sharedPreferences;
    String shared_pref_name="mypref";
    String aadharnumber="aadharnumber";
    MyDatabaseHelper db;
EditText aanum;
Button sendotp;
ArrayList<String> aadharnums;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        aanum=findViewById(R.id.editTextNumber3);
        aadharnums=new ArrayList<>();
        sendotp=findViewById(R.id.button);
        pb=findViewById(R.id.progressBar);
        sharedPreferences=getSharedPreferences(shared_pref_name,MODE_PRIVATE);
    }


    public void Sendotp(View view) {
        String a = aanum.getText().toString();
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putString(aadharnumber,a);
        editor.apply();
        MyDatabaseHelper mydb=new MyDatabaseHelper(MainActivity.this);
        Cursor cursor=mydb.getallaadhars();
        int i=0;
        while(cursor.moveToNext()){
            if(i==0){
                cursor.moveToFirst();
                aadharnums.add(cursor.getString(1));
            }
            else{
                aadharnums.add(cursor.getString(1));
            }
            i++;
        }
        if(aadharnums.contains(a)) {
            if (a.length() != 12) {
                Toast.makeText(this, "Enter valid aadhar number.", Toast.LENGTH_SHORT).show();
            } else {
                pb.setVisibility(View.VISIBLE);
                sendotp.setVisibility(View.INVISIBLE);
                String mobilenumber = displayData(a);
                PhoneAuthProvider.getInstance().verifyPhoneNumber("+91" + mobilenumber, 60, TimeUnit.SECONDS, MainActivity.this, new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                    @Override
                    public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                        pb.setVisibility(View.GONE);
                        sendotp.setVisibility(View.VISIBLE);
                    }

                    @Override
                    public void onVerificationFailed(@NonNull FirebaseException e) {
                        pb.setVisibility(View.GONE);
                        sendotp.setVisibility(View.VISIBLE);
                        Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCodeSent(@NonNull String verificationId, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                        pb.setVisibility(View.GONE);
                        sendotp.setVisibility(View.VISIBLE);
                        Intent intent = new Intent(MainActivity.this, Otpverification.class);
                        intent.putExtra("aamobile", mobilenumber);
                        intent.putExtra("VerificationId", verificationId);
                        startActivity(intent);
                    }
                });

            }
        }
        else{
            Toast.makeText(this, "You entered invalid aadhar number", Toast.LENGTH_SHORT).show();
        }
        }
    String displayData(String aa){
        db=new MyDatabaseHelper(MainActivity.this);
        return db.readAllDAta(aa);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent=new Intent(MainActivity.this,MainActivity.class);
        startActivity(intent);
    }
}

