package com.example.voting;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class Otpverification extends AppCompatActivity {
    Button verify;
    ProgressBar pb1;
    MyDatabaseHelper myDB;
    SharedPreferences sharedPreferences;
    String shared_pref_name="mypref";
    private String verificationId;
    String aadharnumber="aadharnumber";
    TextView phnum;
    EditText input1,input2,input3,input4,input5,input6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otpverification);
        phnum=findViewById(R.id.textView4);
        Toast.makeText(this, "OTP Sent", Toast.LENGTH_SHORT).show();
        phnum.setText("+91-"+getIntent().getStringExtra("aamobile"));
        input1=findViewById(R.id.editTextNumber);
        input2=findViewById(R.id.editTextNumber2);
        input3=findViewById(R.id.editTextNumber4);
        input4=findViewById(R.id.editTextNumber5);
        input5=findViewById(R.id.editTextNumber6);
        input6=findViewById(R.id.editTextNumber7);
        verify=findViewById(R.id.button2);
        pb1=findViewById(R.id.progressBar2);
        sharedPreferences=getSharedPreferences(shared_pref_name,MODE_PRIVATE);
        setupOTPInputs();
        verificationId=getIntent().getStringExtra("VerificationId");
    }
    private void setupOTPInputs(){
        input1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                if(!s.toString().trim().isEmpty()){
                    input2.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        input2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                if(!s.toString().trim().isEmpty()){
                    input3.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        input3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                if(!s.toString().trim().isEmpty()){
                    input4.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        input4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                if(!s.toString().trim().isEmpty()){
                    input5.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        input5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                if(!s.toString().trim().isEmpty()){
                    input6.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }




    public void sagain(View view) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber("+91"+getIntent().getStringExtra("aamobile"),60, TimeUnit.SECONDS,Otpverification.this,new PhoneAuthProvider.OnVerificationStateChangedCallbacks(){
            @Override
            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {

            }

            @Override
            public void onVerificationFailed(@NonNull FirebaseException e) {
                Toast.makeText(Otpverification.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCodeSent(@NonNull String newverificationId, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
              verificationId=newverificationId;
                Toast.makeText(Otpverification.this, "OTP Sent", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void submit(View view) {
        pb1.setVisibility(View.VISIBLE);
        verify.setVisibility(View.INVISIBLE);
        String paanum=sharedPreferences.getString(aadharnumber,null);
        if(input1.getText().toString().trim().isEmpty()||input2.getText().toString().trim().isEmpty()||
                input3.getText().toString().trim().isEmpty()||input4.getText().toString().trim().isEmpty()||
                input5.getText().toString().trim().isEmpty()||input6.getText().toString().trim().isEmpty()){
            Toast.makeText(this, "Please enter valid code", Toast.LENGTH_SHORT).show();
            return;
        }
        String code=input1.getText().toString()+input2.getText().toString()+
                input3.getText().toString()+input4.getText().toString()+
                input5.getText().toString()+input6.getText().toString();
        PhoneAuthCredential phoneAuthCredential= PhoneAuthProvider.getCredential(
                verificationId,
                code
        );
        FirebaseAuth.getInstance().signInWithCredential(phoneAuthCredential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                pb1.setVisibility(View.GONE);
                verify.setVisibility(View.VISIBLE);
                myDB=new MyDatabaseHelper(Otpverification.this);
            String vstatus=myDB.returnstaus(paanum);
                if(task.isSuccessful()){
                    if(vstatus.equals("NO")){
                    Intent intent=new Intent(Otpverification.this,Datadisplay.class);
                    startActivity(intent);}


                else {
                    Toast.makeText(Otpverification.this, "You have already voted", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(Otpverification.this,MainActivity.class);
                    startActivity(intent);
                }}
                else{
                    Toast.makeText(Otpverification.this, "The verification code entered was invalid", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}