package com.example.voting;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class Datadisplay extends AppCompatActivity {
    Button ok;
    SharedPreferences sharedPreferences;
    String shared_pref_name="mypref";
    String aadharnumber="aadharnumber";
    MyDatabaseHelper myDB;
    TextView aanum,aaname,aadob,aagen;
    ProgressBar pb3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datadisplay);
        aaname=findViewById(R.id.textView11);
        pb3=findViewById(R.id.progressBar3);
        aadob=findViewById(R.id.textView12);
        ok=findViewById(R.id.button3);
        ok.setVisibility(View.VISIBLE);
        pb3.setVisibility(View.GONE);
        aagen=findViewById(R.id.textView13);
        aanum=findViewById(R.id.textView14);
        Toast.makeText(this, "You have logged in successfully", Toast.LENGTH_SHORT).show();
        sharedPreferences=getSharedPreferences(shared_pref_name,MODE_PRIVATE);
        myDB=new MyDatabaseHelper(Datadisplay.this);
        String paanum=sharedPreferences.getString(aadharnumber,null);
        Cursor cursor=myDB.displaydata(paanum);
        aaname.setText(cursor.getString(2));
        aadob.setText(cursor.getString(3));
        aagen.setText(cursor.getString(4));
        String a=cursor.getString(1);
        String r=a.substring(0, 4);
        String s=a.substring(4,8);
        String t=a.substring(8,12);
        aanum.setText(r+" "+s+" "+t);
    }


    public void okbutton(View view) {
        Intent intent=new Intent(Datadisplay.this, Scrollbar.class);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent=new Intent(Datadisplay.this,MainActivity.class);
        startActivity(intent);
    }
}